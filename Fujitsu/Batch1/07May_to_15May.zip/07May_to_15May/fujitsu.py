def myfun(a,b):
    return a+b


def greet():
    return "Hello World"


if __name__=="__main__":
    print("hi")
    print("hello World")